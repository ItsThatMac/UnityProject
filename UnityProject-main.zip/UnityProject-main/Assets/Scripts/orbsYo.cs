﻿public interface orbsYo 
{
    void OnStartLook();
    void OnInteract();
    void OnEndLook();
}
